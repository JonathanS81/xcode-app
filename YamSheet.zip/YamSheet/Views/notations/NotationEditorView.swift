//
//  NotationEditorView.swift
//  YamSheet
//
//  Created by Jonathan Sportiche  on 28/08/2025.
//
import SwiftUI
import SwiftData

struct NotationEditorView: View {
    @Environment(\.dismiss) private var dismiss
    @Environment(\.modelContext) private var context
    
    var onCreated: ((Notation) -> Void)? = nil

    @State private var local = Notation(
        name: "Classique",
        tooltipUpper: "Atteignez le seuil pour gagner le bonus.",
        tooltipMiddle: nil, // non édité : affiché via StatsEngine.middleTooltip
        tooltipBottom: "Chaque figure peut être calculée différemment."
    )

    var body: some View {
        NavigationStack {
            Form {
                // Nom
                Section(UIStrings.Notation.name) {
                    TextField(UIStrings.Notation.name, text: $local.name)
                }

                // Tooltips : Upper & Bottom éditables ; Middle est affiché en lecture seule plus bas
                Section(UIStrings.Notation.tooltips) {
                    TextField(UIStrings.Notation.tooltipUpper, text: Binding(
                        get: { local.tooltipUpper ?? "" },
                        set: { local.tooltipUpper = $0 }
                    ))
                    TextField(UIStrings.Notation.tooltipBottom, text: Binding(
                        get: { local.tooltipBottom ?? "" },
                        set: { local.tooltipBottom = $0 }
                    ))
                }

                // Section haute
                Section(UIStrings.Notation.upperSection) {
                    Stepper("\(UIStrings.Notation.upperBonusThresholdLabel) : \(local.upperBonusThreshold)",
                            value: $local.upperBonusThreshold, in: 0...200)
                    Stepper("\(UIStrings.Notation.upperBonusLabel) : \(local.upperBonusValue)",
                            value: $local.upperBonusValue, in: 0...200)
                }

                // Section milieu (tooltip non éditable + champs conditionnels)
                Section(UIStrings.Notation.middleSection) {
                    Picker(UIStrings.Notation.rulePicker, selection: $local.middleModeRaw) {
                        Text(UIStrings.Notation.middleLabel(.multiplier)).tag(MiddleRuleMode.multiplier.rawValue)
                        Text(UIStrings.Notation.middleLabel(.bonusGate)).tag(MiddleRuleMode.bonusGate.rawValue)
                    }

                    // Tooltip auto selon le mode choisi (non éditable)
                    Text(
                        StatsEngine.middleTooltip(
                            mode: MiddleRuleMode(rawValue: local.middleModeRaw) ?? .multiplier,
                            threshold: local.middleBonusSumThreshold,
                            bonus: local.middleBonusValue
                        )
                    )
                    .font(.footnote)
                    .foregroundStyle(.secondary)

                    if MiddleRuleMode(rawValue: local.middleModeRaw) == .bonusGate {
                        Stepper("\(UIStrings.Notation.thresholdSum) : \(local.middleBonusSumThreshold)",
                                value: $local.middleBonusSumThreshold, in: 0...200)
                        Stepper("\(UIStrings.Notation.bonus) : \(local.middleBonusValue)",
                                value: $local.middleBonusValue, in: 0...200)
                    }
                }

                // Section basse — Grande suite (5 dés)
                Section(UIStrings.Notation.bigSuite) {
                    Picker(UIStrings.Notation.modeLabel, selection: $local.suiteBigModeRaw) {
                        Text(UIStrings.Notation.suiteModeLabel(.singleFixed)).tag(SuiteBigMode.singleFixed.rawValue)
                        Text(UIStrings.Notation.suiteModeLabel(.splitFixed)).tag(SuiteBigMode.splitFixed.rawValue)
                    }


                    if local.suiteBigMode == .singleFixed {
                        HStack {
                            Text(UIStrings.Notation.valueFixed).font(.caption).foregroundStyle(.secondary)
                            Spacer()
                            CompactWheelPicker(value: $local.suiteBigFixed,
                                               range: 0...100,
                                               title: UIStrings.Notation.valueFixed)
                        }
                    } else {
                        HStack {
                            Text(UIStrings.Notation.suite15Lbl).font(.caption).foregroundStyle(.secondary)
                            Spacer()
                            CompactWheelPicker(value: $local.suiteBigFixed1to5,
                                               range: 0...100,
                                               title: UIStrings.Notation.suite15Lbl)
                        }
                        HStack {
                            Text(UIStrings.Notation.suite20Lbl).font(.caption).foregroundStyle(.secondary)
                            Spacer()
                            CompactWheelPicker(value: $local.suiteBigFixed2to6,
                                               range: 0...100,
                                               title: UIStrings.Notation.suite20Lbl)
                        }
                    }
                }

                // Section basse — Règles des figures
                Section(UIStrings.Notation.bottomRules) {
                    FigureRuleRow(title: "Brelan",       rule: $local.ruleBrelan)
                    FigureRuleRow(title: "Chance",       rule: $local.ruleChance)
                    FigureRuleRow(title: "Full",         rule: $local.ruleFull)
                    FigureRuleRow(title: "Petite suite", rule: $local.rulePetiteSuite)
                    FigureRuleRow(title: "Carré",        rule: $local.ruleCarre)
                    FigureRuleRow(title: "Yams",         rule: $local.ruleYams)

                    Section("Prime Yams supplémentaire") {
                        HStack {
                            Text("Montant")
                            Spacer()
                            TextField("0", value: $local.extraYamsBonusValue, format: .number)
                                .keyboardType(.numberPad)
                                .frame(width: 80)
                                .multilineTextAlignment(.trailing)
                        }
                        Text("Astuce : mettre 0 pour désactiver cette prime dans la notation. L’activation finale se fait à la création d’une partie.")
                            .font(.footnote)
                            .foregroundStyle(.secondary)
                    }
                    .onChange(of: local.extraYamsBonusValue) { oldVal, newVal in
                        local.extraYamsBonusEnabled = newVal > 0
                    }                }

                // Tooltip bas (affichage)
                if let tip = local.tooltipBottom, !tip.isEmpty {
                    Section {
                        Text(tip).font(.footnote).foregroundStyle(.secondary)
                    }
                }
            }

            .navigationTitle("Nouvelle notation")
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button("Annuler") { dismiss() }
                }
                ToolbarItem(placement: .confirmationAction) {
                    Button("Créer") {
                        context.insert(local)
                        try? context.save()
                        if let cb = onCreated {
                            cb(local)           // remonte la notation au parent (NewGameView)
                            // on ne dismiss pas ici : NewGameView fermera la sheet
                        } else {
                            dismiss()           // cas d'usage en autonome
                        }
                    }
                    .disabled(local.name.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty)
                }
            }
        }
    }
}
